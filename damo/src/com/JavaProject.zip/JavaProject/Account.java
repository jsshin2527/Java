package com.JavaProject;

import java.io.ObjectInputStream;
import java.util.List;

public interface Account {

	public void input();
	public void filestore(List aclists);
	public void accountstore(List aclists);
	public void output();
	public void login();
	
	
}
