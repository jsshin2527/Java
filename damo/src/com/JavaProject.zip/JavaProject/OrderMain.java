package com.JavaProject;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class OrderMain {
	
		public OrderMain() {
		
		}
		
		public void ordermain(String fileid) {
			
		Scanner sc = new Scanner(System.in);
		AccountImpl aim = new AccountImpl();
		OrderImpl ob = new OrderImpl(fileid);

		int ch = 0;
		
		while(true) {
			do { 
				System.out.println("\n1. 메뉴 \n2. 주문하기 \n3. 제품출력 \n4. 종료");
				System.out.print("메뉴얼을 선택하세요 : ");
				ch = sc.nextInt();
				
			}while(ch<1);
			
			switch (ch) {
			case 1 :
				ob.menu();break;
			case 2 :
				ob.order();break;
			case 3 :
				ob.keepoutput();break;
			case 4 :
				System.exit(0);
			default:
				System.exit(0);
				
			}	
		}		
	}
}

