package com.BMI;

public class BMiMain {

	public static void main(String[] args) {
		
		Information_Method ob = new BMI_Impl();
		
		ob.set();
		ob.input();
		ob.print();
	}

}
