package com.BMI;

public interface Information_Method {

	public void set();
	public void input();
	public void print();
}
