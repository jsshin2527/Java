package com.BMI;

public class Record {
	
	int cumstomid;
	String name;
	double tall,kg;
	double bmi;
}
