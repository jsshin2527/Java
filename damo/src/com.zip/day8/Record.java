package com.day8;

public class Record {
	
	String name;
	int[] score = new int[3];
	int tot;
	int avg;
	String[] eva = new String[3];

}
