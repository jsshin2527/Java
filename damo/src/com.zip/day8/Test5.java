package com.day8;

import java.util.Calendar;

public class Test5 {

	public static void main(String[] args) {
		
		//Data ob = new Data();
		//ob.print();
		
		Data.getprint();
		Data.name = "����";
		
		Calendar now = Calendar.getInstance();//Call by Reference(Static)

	}

}
