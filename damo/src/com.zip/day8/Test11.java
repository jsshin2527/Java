package com.day8;

import com.day9.ConstructorExample;

public class Test11 {
	
	
	
	public static void main(String[] args) 	{
		

	}
	
}

	


