package com.day8;

public class ScoreMain {

	public static void main(String[] args) {
		
		Test4 ob = new Test4();
		
		ob.set();
		ob.input();
		//ob.evaluation();
		ob.print();
		
		

	}

}
