package com.score2;

public class Record {

		String hak;
		String name;
		int kor,eng,mat;
		int tot,avg;	

}