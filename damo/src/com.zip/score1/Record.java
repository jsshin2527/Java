package com.score1;

public class Record {
	
	String name;
	int[] score = new int[3];//������
	int tot,avg,rank;
	
}	
	