package com.day7;

public class Test9 {

	public static void main(String[] args) {
		
		Aaa r = new Aaa();
		
		r.input();
		int a = r.oper();
		r.print(a);
		
		
		
		

	}

}
