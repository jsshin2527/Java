package com.day7;

public class Test6 {

	public static void main(String[] args) {
		
		Rect usa = new Rect();
		
		usa.input();
		int aa = usa.area();
		int ll = usa.length();
		usa.print(aa, ll);
				
		

	}

}
