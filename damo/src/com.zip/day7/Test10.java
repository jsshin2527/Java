package com.day7;

public class Test10 {

	public static void main(String[] args) {
		
		Bbb r = new Bbb();
		
		int a = r.input();
		r.print(a);
		
		
		
		
		

	}

}
