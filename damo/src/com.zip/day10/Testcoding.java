package com.day10;

/*
class Shape1{
	
	private String title;
	
	protected double area;
	
	public Shape1() {}
	
	public Shape1(String title) {
		this.title = title;
	}
	
	public void write() {
		System.out.println(title+" : "+ area);
	}
}
*/

public class Testcoding {	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	}

}
